# OIBSIP_Task2
TASK-2:- [Tribute page](https://github.com/Anjalimishra14/OIBSIP_Task2/commit/9f0c460e66ceb1ecaf1b895da57db6d7f7966a41) (It is a Oasis Infobyte Level 2 Task 2 of code to develop a Tribute Page. It is written using HTML, CSS and JavaScript. Here I made Tribute Page of ALBERT EINSTEIN.)
